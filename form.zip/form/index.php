<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/images/favicon.ico" type="image/svg+xml" sizes="any" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/style.css">
    <title>Registraion Form</title>
</head>

<body>
    <!-- Header -->
    <header>
        <!-- Site Header -->
        <div class="site-header">
            <nav class="navbar navbar-expand-md navbar-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/"><img src="assets/images/Full Logo (Red+Black) Transparent 1.png" alt="Brand Logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Gigs</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Team Gigs</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Join as freelancer</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- multistep form -->
    <section class="app_form">
        <div class="container">
            <div>
                <?php
                   
                   $server = "localhost";
                   $username = "root";
                   $password = "";
                   $dbname = "insert";

                   $conn = mysqli_connect($server, $username, $password, $dbname);


                     if(isset($_POST['create'])){
                         echo 'Form Submited  > ';
                     $fullname   = $_POST['fullname'];
                     $age        = $_POST['age'];
                     $city       = $_POST['city'];
                     $work       = $_POST['work'];
                     $file       = $_POST['file'];
                     $experience = $_POST['experience'];
                     $review     = $_POST['review'];
                     
                     $query = "insert into form1(fullname,age,city,work,file,experience,review) 
                     value('$fullname', '$age' , '$city', '$work', '$file', '$experience', '$review') ";
                     
                     $run = mysqli_query($conn , $query);

                     if($run){
                         echo "Form Sumitted Successfully";
                     }else{
                         echo " Error";
                     }                     

                    echo $fullname . " " . $age . " " . $city . " " . $work . " " . $file . " " . $experience . " " . $review;

                     }
                
                ?>
            </div>
            <form id="msform" action="index.php" method="post">
                <!-- progressbar -->
                <ul id="progressbar">
                    <li class="active">Account Setup</li>
                    <li>Social Profiles</li>
                    <li>Personal Details</li>
                </ul>
                <!-- fieldset 1 -->
                <fieldset class="form_fieldset">
                    <h2>About Me</h2>
                    <div class="form_field">
                        <label for="featureReview" class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="fullname" id="fullName" required>
                    </div>
                    <div class="form_field">
                        <label for="age" class="form-label">Age <i class="fas fa-lock"></i></label>
                        <select class="form-select form-select-lg" name="age" aria-label="age select" id="age">
                            <option value="0" selected>0</option>
                            <option value="1">Under 18</option>
                            <option value="2">18 To 30</option>
                            <option value="3">30 To 40</option>
                            <option value="4">Up To 40</option>
                          </select>
                    </div>
                    <div class="form_field">
                        <label for="cityCountry" class="form-label">City & Country</label>
                        <input type="text" class="form-control" name="city" id="cityCountry" required>
                    </div>
                    
                    <h2>Work Experience <?php
                       echo $fullname;
                    ?>  </h2>
                    <div class="form_field experience">
                        <label for="experience" class="form-label">(3 main ones- max 100 words)</label>
                        <input type="text" class="form-control" name="work" id="experience" value="1." required>
                        <input type="text" class="form-control" id="experience1" value="2.">
                        <input type="text" class="form-control" id="experience2" value="3.">
                    </div>
                    <div class="form_field">
                        <label class="form-label">Professional Qualification (Attached Qualifications)</label>
                        <label for="attachment" class="attachment">
                            <input type="file" id="attachment" name="file">
                            <i class="fal fa-paperclip"></i>
                        </label>
                    </div>
                    <div class="form_field">
                        <label for="totalExperience" class="form-label">Total Years’ Experience</label>
                        <select class="form-select form-select-lg" name="experience" aria-label="Total Years’ Experience" id="totalExperience">
                            <option value="0" selected>0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                    </div>
                    <h2>Featured Review</h2>
                    <div class="form_field">
                        <label for="featureReview" class="form-label">(max 100 words)</label>
                        <textarea class="form-control" id="featureReview" name="review" rows="8"></textarea>
                    </div>
                    <div class="btn_container">
                    <!-- class="next site-btn" this is class for this input feild -->
                        <input type="submit" name="create"  value="Save & Continue" />
                    </div>
                </fieldset>  


                <!-- fieldset 2 -->
                <fieldset class="form_fieldset">
                    <div class="row justify-content-between g-0">
                        <div class="form_field gig_img">
                            <label class="form-label">Upload Gig Image</label>
                            <label for="attachment" class="attachment">
                            <input type="file" id="attachment">
                            <span class="plus_icon">
                            <i class="fal fa-plus"></i>
                            </span>
                            Upload Gig Image
                        </label>
                        </div>
                        <div class="form_field prof_img">
                            <label class="form-label">Profile Picture</label>
                            <label for="attachment" class="attachment">
                            <input type="file" id="attachment">
                            <i class="fas fa-user-alt"></i>
                            Upload Profile Picture
                        </label>
                        </div>
                        <div class="form_field">
                            <label for="gigTitle" class="form-label">Gig Title</label>
                            <input type="text" class="form-control" id="gigTitle">
                        </div>
                        <h2>Why Hire me?</h2>
                        <div class="form_field experience">
                            <label for="experience" class="form-label">(3 reasons- max 100 words)</label>
                            <input type="text" class="form-control" id="reasons" value="1.">
                            <input type="text" class="form-control" id="reasons1" value="2.">
                            <input type="text" class="form-control" id="reasons2" value="3.">
                        </div>
                        <div class="form_field">
                            <label for="startPrice" class="form-label">Starting Price</label>
                            <div class="input-group">
                                <span class="input-group-text" id="startPrice">$</span>
                                <input type="text" class="form-control" aria-label="startPrice" aria-describedby="startPrice">
                            </div>
                        </div>
                        <div class="form_field">
                            <label for="hourlyRate" class="form-label">Hourly Rate</label>
                            <div class="input-group">
                                <span class="input-group-text" id="hourlyRate">$</span>
                                <input type="text" class="form-control" aria-label="hourlyRate" aria-describedby="hourlyRate">
                            </div>
                        </div>
                    </div>
                    <div class="btn_container">
                        <input type="button" name="next" class="previous btn" value="Go Back" />
                        <input type="button" name="next" class="next site-btn" value="Save & Continue" />
                    </div>
                </fieldset>


                <!-- fieldset 3 -->
                <fieldset class="form_fieldset">
                    <div class="form_table">
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="head_title">
                                    Package Type
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="head_title bg">
                                    Basic
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Price
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XX">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Overall Main Info <br> (max 150 words)
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <textarea type="text" class="form-control" placeholder="Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam."></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Deliverables
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    1.
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="Source File">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    2.
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="2 Concepts">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    3.
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="High Resolution">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    4.
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    5.
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Revisions
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box form_field">
                                    <select class="form-select" aria-label="Revisions">
                                    <option selected>Select Revisions</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                  </select>
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Delivery Time
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box form_field">
                                    <select class="form-select" aria-label="Select Delivery Time">
                                    <option selected>Select Delivery Time</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                  </select>
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title optional">
                                    Option For Upgrades
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">

                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Additional Page
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XX">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Plug-In Installation
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XX">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Additional Revision
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XX">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Fast Delivery Time
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XX">
                                </div>
                            </div>
                        </div>
                        <div class="row g-0">
                            <div class="col-xl-3 col-lg-4">
                                <div class="field_title">
                                    Final Price
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-8">
                                <div class="field_box">
                                    <input type="text" class="form-control" placeholder="$XXxx">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form_field work gig_img">
                        <label class="form-label">Upload a Work Samples <span>(Up to 6 Work Samples)</span></label>
                        <label for="attachment" class="attachment">
                    <input type="file" id="attachment" multiple>
                    <span class="plus_icon">
                    <i class="fal fa-plus"></i>
                    </span>
                    Upload Work
                </label>
                    </div>
                    <div class="btn_container">
                        <input type="button" name="next" class="previous btn" value="Go Back" />
                        <input type="button" name="next" class="next site-btn" value="Submit Application" />
                    </div>
                </fieldset>

                
            </form>
        </div>
    </section>
    <!-- Site Footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-5 col-md-5 footer-logo">
                    <img src="assets/images/logo-white.png" alt="Rate Hours">
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis.</p>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 links">
                    <h3>About</h3>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><a href="#">Rate Hour</a></li>
                        <li class="list-group-item"><a href="#">Private Policy</a></li>
                        <li class="list-group-item"><a href="#">Term Of Service</a></li>
                    </ul>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 links">
                    <h3>Support</h3>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><a href="#">Help &amp; Support</a></li>
                        <li class="list-group-item"><a href="#">Selling on Rate Hour</a></li>
                        <li class="list-group-item"><a href="#">Buying on Rate Hour</a></li>
                    </ul>
                </div>
            </div>
            <div class="row social">
                <div class="col-md-4">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item ps-0"><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li class="list-group-item"><a href="#"><i class="fab fa-linkedin"></i></a></li>
                        <li class="list-group-item"><a href="#"><i class="fab fa-facebook"></i></a></li>
                        <li class="list-group-item"><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                        <li class="list-group-item"><a href="#"><i class="fab fa-instagram"></i></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-bar">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-auto">
                    <p>© Rate Hour International Ltd. 2021</p>
                </div>
                <div class="col-auto">
                    <div class="btn btn-default">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-globe" viewBox="0 0 16 16">
                            <path
                                d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm7.5-6.923c-.67.204-1.335.82-1.887 1.855A7.97 7.97 0 0 0 5.145 4H7.5V1.077zM4.09 4a9.267 9.267 0 0 1 .64-1.539 6.7 6.7 0 0 1 .597-.933A7.025 7.025 0 0 0 2.255 4H4.09zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a6.958 6.958 0 0 0-.656 2.5h2.49zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5H4.847zM8.5 5v2.5h2.99a12.495 12.495 0 0 0-.337-2.5H8.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5H4.51zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5H8.5zM5.145 12c.138.386.295.744.468 1.068.552 1.035 1.218 1.65 1.887 1.855V12H5.145zm.182 2.472a6.696 6.696 0 0 1-.597-.933A9.268 9.268 0 0 1 4.09 12H2.255a7.024 7.024 0 0 0 3.072 2.472zM3.82 11a13.652 13.652 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5H3.82zm6.853 3.472A7.024 7.024 0 0 0 13.745 12H11.91a9.27 9.27 0 0 1-.64 1.539 6.688 6.688 0 0 1-.597.933zM8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855.173-.324.33-.682.468-1.068H8.5zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.65 13.65 0 0 1-.312 2.5zm2.802-3.5a6.959 6.959 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5h2.49zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.024 7.024 0 0 0-3.072-2.472c.218.284.418.598.597.933zM10.855 4a7.966 7.966 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4h2.355z">
                            </path>
                        </svg>English
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Script -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        //jQuery time
        var current_fs, next_fs, previous_fs; //fieldsets
        var left, opacity, scale; //fieldset properties which we will animate
        var animating; //flag to prevent quick multi-click glitches

        $(".next").click(function() {
            if (animating) return false;
            animating = true;

            current_fs = $(this).parent().parent();
            next_fs = $(this).parent().parent().next();

            //activate next step on progressbar using the index of next_fs
            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            //show the next fieldset
            next_fs.show();
            //hide the current fieldset with style
            current_fs.animate({
                opacity: 0
            }, {
                step: function(now, mx) {
                    //as the opacity of current_fs reduces to 0 - stored in "now"
                    //1. scale current_fs down to 80%
                    scale = 1 - (1 - now) * 0.2;
                    //2. bring next_fs from the right(50%)
                    left = (now * 50) + "%";
                    //3. increase opacity of next_fs to 1 as it moves in
                    opacity = 1 - now;
                    current_fs.css({
                        'transform': 'scale(' + scale + ')',
                        'position': 'absolute'
                    });
                    next_fs.css({
                        'left': left,
                        'opacity': opacity
                    });
                },
                duration: 800,
                complete: function() {
                    current_fs.hide();
                    animating = false;
                },
                //this comes from the custom easing plugin
                easing: 'easeInOutBack'
            });
        });

        $(".previous").click(function() {
            if (animating) return false;
            animating = true;

            current_fs = $(this).parent().parent();
            previous_fs = $(this).parent().parent().prev();

            //de-activate current step on progressbar
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

            //show the previous fieldset
            previous_fs.show();
            //hide the current fieldset with style
            current_fs.animate({
                opacity: 0
            }, {
                step: function(now, mx) {
                    //as the opacity of current_fs reduces to 0 - stored in "now"
                    //1. scale previous_fs from 80% to 100%
                    scale = 0.8 + (1 - now) * 0.2;
                    //2. take current_fs to the right(50%) - from 0%
                    left = ((1 - now) * 50) + "%";
                    //3. increase opacity of previous_fs to 1 as it moves in
                    opacity = 1 - now;
                    current_fs.css({
                        'left': left
                    });
                    previous_fs.css({
                        'transform': 'scale(' + scale + ')',
                        'opacity': opacity,
                        'position': 'relative'
                    });
                },
                duration: 800,
                complete: function() {
                    current_fs.hide();
                    animating = false;
                },
                //this comes from the custom easing plugin
                easing: 'easeInOutBack'
            });
        });

        $(".submit").click(function() {
            return false;
        })
    </script>
</body>

</html>